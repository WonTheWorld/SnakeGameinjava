# SnakeGameinJavaprogramming
# Output

![Screenshot 2023-08-25 234917](https://github.com/Biswaranjansahoo96/SnakeGameinJavaprogramming/assets/126255979/4064eca2-4b35-4a47-bbec-19d627837f4a)
# Game open

![Screenshot 2023-08-25 234934](https://github.com/Biswaranjansahoo96/SnakeGameinJavaprogramming/assets/126255979/9c6a8ed3-dae3-426c-a49e-862b3b74af5a)

# Game Score

![Screenshot 2023-08-25 234951](https://github.com/Biswaranjansahoo96/SnakeGameinJavaprogramming/assets/126255979/8aa185a5-484f-43a9-8b06-41f6ad25cbc0)
